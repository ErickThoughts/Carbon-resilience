import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm, trange
import random
import os

def mse_loss(y_true, y_pred):
    return torch.mean((y_true - y_pred)**2)

def mae_loss(y_true, y_pred):
    return torch.mean(torch.abs(y_true - y_pred))

def get_datasets(path, window=1):
    data = pd.read_csv(path, header=0)
    datasets = []
    for i in range(len(data[:1179])): # before 2022/3/23
        line = data.iloc[i][1:]
        shangh = float(line.pop("Shanghai"))
        # shangh = float(line['Shanghai'])
        line = [float(item) for item in line]
        line.append(shangh)
        datasets.append(np.array(line))
    datasets = np.array(datasets)
    # prepare dataset with specific window size
    features = []
    labels = []
    for i in range(window, len(datasets)):
        # feature = datasets[i-window:i, -1:np.newaxis]
        # feature = datasets[i-window:i, :]
        feature = datasets[i-window:i, :-1]
        label = datasets[i][-1]
        features.append(feature)
        labels.append(label)
    # split
    x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, shuffle = False)

    return np.array(x_train), np.array(x_test), np.array(y_train), np.array(y_test)

class MyDataset(Dataset):
    def __init__(self, features, labels):
        self.features = torch.tensor(features, dtype=torch.float).cuda()
        self.labels = torch.tensor(labels, dtype=torch.float).cuda()

    def __len__(self):
        return self.features.shape[0]

    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]

# 权重初始化，默认xavier
def init_network(model, method='xavier', exclude='embedding', seed=42):
    for name, w in model.named_parameters():
        if exclude not in name:
            if 'weight' in name:
                if method == 'xavier':
                    nn.init.xavier_normal_(w)
                elif method == 'kaiming':
                    nn.init.kaiming_normal_(w)
                else:
                    nn.init.normal_(w)
            elif 'bias' in name:
                nn.init.constant_(w, 0)
            else:
                pass

class Model(nn.Module):
    def __init__(self, input_dim, hidden_size=128, num_layers=1, dropout_prob=0.3):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_size, num_layers,
                            bidirectional=True, batch_first=True, dropout=dropout_prob)
        self.fc=nn.Sequential(nn.Linear(hidden_size*2, hidden_size),
                      nn.Dropout(dropout_prob),
                      nn.Linear(hidden_size, 1))
    
    def forward(self, features, labels):
        output, _ = self.lstm(features)
        predictions = self.fc(output)
        loss_fn = nn.MSELoss()
        loss = loss_fn(predictions, labels)
        
        return loss, predictions, labels

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

def train(model, train_dataloader, test_dataloader, learning_rate=1e-3, num_epochs=200, save_path="./checkpoints/", require_improvement=2000, seed=42):
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    total_batch = 0
    dev_best_loss = 1000.0
    last_improve = 0
    flag = False
    all_loss = 0.0
    model.zero_grad()
    set_seed(seed)
    for epoch in range(num_epochs):
        epoch_iterator = tqdm(train_dataloader, desc="Iteration")
        print('Epoch [{}/{}]'.format(epoch + 1, num_epochs))
        trues = []
        preds = []
        for i, (features, labels) in enumerate(epoch_iterator):
            model.train()
            loss, predictions, goldens = model(features, labels)
            loss.backward()
            total_batch += 1
            all_loss += loss.item()
            epoch_iterator.set_description('Loss: {}'.format(round(loss.item(), 6)))
            optimizer.step()
            model.zero_grad()
            true = goldens.detach().cpu().numpy()
            pred = predictions.detach().cpu().numpy()
            for i in range(len(true)):
                trues.append(true[i])
                preds.append(pred[i])
            if total_batch - last_improve > require_improvement:
                print("No optimization for a long time, auto-stopping...")
                flag = True
                break
        dev_loss, mae = test(model, test_dataloader)
        if dev_loss < dev_best_loss:
            dev_best_loss = dev_loss
            torch.save(model.state_dict(), os.path.join(save_path, "model"))
            improve = 'TURE'
            last_improve = total_batch
        else:
            improve = 'FALSE'
        trues = torch.tensor(trues)
        preds = torch.tensor(preds)
        mse_t = mse_loss(trues, preds)
        mae_t = mae_loss(trues, preds)
        msg = 'Iter: {},  Train MSE Loss: {:.4f}, Val MSE Loss: {:.4f}, Val MAE Loss: {:.4f}, improve: {}'
        print(msg.format(total_batch, mse_t, dev_loss, mae, improve))
        if flag:
            break
    test(model, test_dataloader)


def test(model, test_dataloader, save_path="./checkpoints/"):
    model.eval()
    trues = []
    preds = []
    epoch_iterator = tqdm(test_dataloader, desc="Iteration")
    for i, (features, labels) in enumerate(epoch_iterator):
        with torch.no_grad():
            loss, predictions, goldens = model(features, labels)
            true = goldens.detach().cpu().numpy()
            pred = predictions.detach().cpu().numpy()
            for i in range(len(true)):
                trues.append(true[i])
                preds.append(pred[i])
    
    trues = torch.tensor(trues)
    preds = torch.tensor(preds)
    mse = mse_loss(trues, preds)
    mae = mae_loss(trues, preds)
    return mse, mae


def main():
    data_path = "./data/industry_scale_3years.csv"
    window = 1
    x_train, x_test, y_train, y_test = get_datasets(data_path, window)
    train_data = MyDataset(x_train, y_train)
    test_data = MyDataset(x_test, y_test)
    train_dataloader = DataLoader(train_data, batch_size=64, shuffle=False)
    test_dataloader = DataLoader(test_data, batch_size=64, shuffle=False)

    model = Model(x_train.shape[-1]).cuda()
    set_seed()
    init_network(model)

    train(model, train_dataloader, test_dataloader)

    state_dict = torch.load(os.path.join("./checkpoints/", "model"))
    model.load_state_dict(state_dict)
    model.cuda()
    mse, mae = test(model, test_dataloader)
    print("Testing results: MSE: {:.4f}, MAE: {:.4f}".format(mse, mae))

if __name__ == "__main__":
    main()    

